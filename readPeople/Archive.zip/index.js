const dynamoose = require("dynamoose");

const peopleSchema = new dynamoose.Schema({
  id: String,
  Name: String,
  Phone: String

});

const PeopleModel = dynamoose.model("People", peopleSchema);


exports.handler = async (event) => {

  console.log(event);

  const peopleData = await PeopleModel.query().exec();

  const response = {
    statusCode: 200,
    body: JSON.stringify(peopleData),
  };
  return response;
};
